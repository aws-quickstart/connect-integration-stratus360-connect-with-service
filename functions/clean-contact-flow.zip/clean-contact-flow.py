import json
import logging
import boto3
import uuid
import queue
import os
from urllib.parse import unquote_plus

import argparse
from argparse import RawTextHelpFormatter

s3_client = boto3.client('s3')
ssm_client = boto3.client('ssm')

logger = logging.getLogger()
logger.setLevel(logging.getLevelName("INFO"))

def lambda_handler(event, context):
    
    logger.info('Event: {}'.format(event))
    # logger.info('Context: {}'.format(context))

    for record in event['Records']:
        
        #Get bucket and key information on which file to download
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])

        logger.info("Bucket: {}".format(bucket))
        logger.info("Key: {}".format(key))


        #Get file 
        keysplit = key.split('/')
        tmpkey = key.replace('/', '')
        download_path = '/tmp/{}{}'.format(uuid.uuid4(), tmpkey)

        #Download file temporary
        s3_client.download_file(bucket, key, download_path)

        #Get ssm params information for processing
        ssm_payload = ssm_client.get_parameter(
            Name=os.environ["SSM_PARAM_PATH"]
        )
        params = json.loads(ssm_payload['Parameter']['Value'])
        
        #Do some processing
        data = {}
        with open(download_path) as file_obj:
            data = process_call_flow(json.load(file_obj),params)
            
        with open(download_path,'w') as json_file:
            json.dump(data,json_file)

        #Upload to output 
        upload_key = '{}{}{}'.format('/'.join(keysplit[0:-2]),'/output/',keysplit[-1])
        
        logger.info("Cleaned contact uploaded to bucket: '{}'\n at key: '{}'".format(bucket,upload_key))
        
        s3_client.upload_file(download_path, bucket, upload_key)
        

def process_call_flow(data,params):
    logger.info("Data: {}".format(data))
    logger.info("Params: {}".format(params))
    
    id_node_map = {}
    id_list = []

    #Option settings:
    invert = params["invert"]
    prioritize_depth = params["prioritize_depth"]
    set_loop_behaviour = params["set_loop_behaviour"]
    set_spread_behaviour = params["set_spread_behaviour"]
    depth_difference = params["depth_difference"]
    width_difference = params["width_difference"]
    depth_offset = params["depth_offset"]
    width_offset = params["width_offset"]
    entry = params["entry"]
    # invert = params[invert]
    # prioritize_depth = os.environ["PRIORITIZE_DEPTH"].lower() == "true"
    # set_loop_behaviour = os.environ["SET_LOOP_BEHAVIOUR"].lower() == "true"
    # set_spread_behaviour = os.environ["SET_SPREAD_BEHAVIOUR"].lower() == "true"
    # depth_difference = int(os.environ["DEPTH_DIFFERENCE"])
    # width_difference = int(os.environ["WIDTH_DIFFERENCE"])
    # depth_offset = int(os.environ["DEPTH_OFFSET"])
    # width_offset = int(os.environ["WIDTH_OFFSET"])
    # entry = {
    #     "x": int(os.environ["ENTRY_X"]),
    #     "y": int(os.environ["ENTRY_Y"])
    # }
    
    #populate id to node map
    for node in data['modules']:
        id_list.append(node['id'])
        id_node_map[node['id']]=node
        #set custom depth, delete this at the end after clean
        id_node_map[node['id']]['depth'] = 0 
    
    # print('node:\n')
    # print(id_node_map)


    #BFS START
    
    start_node_id = data['start']
    id_node_map[start_node_id]['depth'] = 1 
    max_depth = 1

    #make a queue of id nodes, start by adding id of start
    q = queue.Queue()
    q.put(start_node_id)
    while not q.empty():
        next_node = id_node_map[q.get()]

        #push into q and update depth of upcoming nodes
        for node in next_node['branches']:
            future_node_id = node['transition']

            if(id_node_map[future_node_id]['depth'] == 0):
                q.put(future_node_id)

            if(prioritize_depth):
                id_node_map[future_node_id]['depth'] = next_node['depth'] + 1
            else:
                if(id_node_map[future_node_id]['depth'] == 0):
                    id_node_map[future_node_id]['depth'] = next_node['depth'] + 1
            #update max depth
            max_depth = max(id_node_map[future_node_id]['depth'],max_depth)

    
    #Sort nodes into a list of lists, where first index is based on the depth of the nodes
    templist = []
    for i in range(max_depth):
        templist.append([])
    
    
    for node_id in id_list:
        templist[id_node_map[node_id]['depth']-1].append(id_node_map[node_id])
    
    max_width = 0
    for i in range(max_depth):
        if(max_width < len(templist[i])):
            max_width = len(templist[i])
    
    for x in range(len(templist)):
        width_diff = max_width / len(templist[x]) 
        for y in range(len(templist[x])):
            y_diff = y
            if(set_spread_behaviour):
                y_diff = (y+1)*width_diff - 1
                
            temp_pos = {}
            if(set_loop_behaviour):
                if(invert):
                    temp_pos ={
                        "x":y_diff*depth_difference + ((x*depth_offset)% depth_difference),
                        "y":x*width_difference + ((y_diff*width_offset)% width_difference)
                    }
                else:
                    temp_pos ={
                        "x":x*depth_difference + ((y_diff*width_offset)% depth_difference),
                        "y":y_diff*width_difference + ((x*depth_offset)% width_difference)
                    }
            else:
                if(invert):
                    temp_pos ={
                        "x":y_diff*depth_difference + x*depth_offset,
                        "y":x*width_difference + y_diff*width_offset
                    }
                else:
                    temp_pos ={
                        "x":x*depth_difference + y_diff*width_offset,
                        "y":y_diff*width_difference + x*depth_offset
                    }
                    
            #update the metadata position info, and delete the depth info I inserted before
            templist[x][y]['metadata']['position'] = temp_pos
            templist[x][y].pop('depth',None)

    data['metadata']['entryPointPosition'] = entry

    return data
