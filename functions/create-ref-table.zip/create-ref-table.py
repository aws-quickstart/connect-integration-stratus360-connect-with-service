import boto3
import os

glue_client = boto3.client("glue")
ssm_client = boto3.client("ssm")

ref_database_name = os.environ["REF_DATABASE_NAME"]
ref_table_name = os.environ["REF_TABLE_NAME"]
param_attributes = os.environ["SSM_PARAM_ATTRIBUTES_PATH"]

def lambda_handler(event, context):
    if(not db_exists()):
    	glue_client.create_database(DatabaseInput={'Name':ref_database_name})
    
    #Get the paramseters of the storage descriptor
    ssm_payload = ssm_client.get_parameter(
        Name=param_attributes
    )
    list_attributes = ssm_payload['Parameter']['Value'].split(',')
    
    
    ref_table_storagedescriptor = generate_storagedescriptor(list_attributes)
    table_input = {
    	'Name': ref_table_name,
    	'StorageDescriptor':ref_table_storagedescriptor
    }
    
    if(table_exists()):
    	glue_client.update_table(DatabaseName=ref_database_name, TableInput=table_input)
    else:
    	glue_client.create_table(DatabaseName=ref_database_name, TableInput=table_input)

def table_exists():
	response_tables = glue_client.get_tables(DatabaseName=ref_database_name, Expression=ref_table_name)
	if(list_contains_name(response_tables['TableList'],ref_table_name)):
		return True
	while 'NextToken' in response_tables:
		response_tables = glue_client.get_tables(NextToken=response_tables['NextToken'])
		if(list_contains_name(response_tables['TableList'],ref_table_name)):
			return True
	return False

def generate_storagedescriptor(list_attributes):
	str_attributes_type = '{}{}{}'.format('struct<',':string,'.join(list_attributes),':string>')
	cols = [
	   {
	      "Name":"awsaccountid",
	      "Type":"string"
	   },
	   {
	      "Name":"awscontacttracerecordformatversion",
	      "Type":"string"
	   },
	   {
	      "Name":"agent",
	      "Type":"struct<ARN:string,AfterContactWorkDuration:int,AfterContactWorkEndTimestamp:string,AfterContactWorkStartTimestamp:string,AgentInteractionDuration:int,ConnectedToAgentTimestamp:string,CustomerHoldDuration:int,HierarchyGroups:string,LongestHoldDuration:int,NumberOfHolds:int,RoutingProfile:struct<ARN:string,Name:string>,Username:string>"
	   },
	   {
	      "Name":"agentconnectionattempts",
	      "Type":"int"
	   },
	   {
	      "Name":"attributes",
	      "Type":str_attributes_type
	   },
	   {
	      "Name":"channel",
	      "Type":"string"
	   },
	   {
	      "Name":"connectedtosystemtimestamp",
	      "Type":"string"
	   },
	   {
	      "Name":"contactid",
	      "Type":"string"
	   },
	   {
	      "Name":"customerendpoint",
	      "Type":"struct<Address:string,Type:string>"
	   },
	   {
	      "Name":"disconnecttimestamp",
	      "Type":"string"
	   },
	   {
	      "Name":"initialcontactid",
	      "Type":"string"
	   },
	   {
	      "Name":"initiationmethod",
	      "Type":"string"
	   },
	   {
	      "Name":"initiationtimestamp",
	      "Type":"string"
	   },
	   {
	      "Name":"instancearn",
	      "Type":"string"
	   },
	   {
	      "Name":"lastupdatetimestamp",
	      "Type":"string"
	   },
	   {
	      "Name":"mediastreams",
	      "Type":"array<struct<Type:string>>"
	   },
	   {
	      "Name":"nextcontactid",
	      "Type":"string"
	   },
	   {
	      "Name":"previouscontactid",
	      "Type":"string"
	   },
	   {
	      "Name":"queue",
	      "Type":"struct<ARN:string,DequeueTimestamp:string,Duration:int,EnqueueTimestamp:string,Name:string>"
	   },
	   {
	      "Name":"recording",
	      "Type":"struct<DeletionReason:string,Location:string,Status:string,Type:string>"
	   },
	   {
	      "Name":"recordings",
	      "Type":"array<struct<DeletionReason:string,FragmentStartNumber:string,FragmentStopNumber:string,Location:string,MediaStreamType:string,ParticipantType:string,StartTimestamp:string,Status:string,StopTimestamp:string,StorageType:string>>"
	   },
	   {
	      "Name":"systemendpoint",
	      "Type":"struct<Address:string,Type:string>"
	   },
	   {
	      "Name":"transfercompletedtimestamp",
	      "Type":"string"
	   },
	   {
	      "Name":"transferredtoendpoint",
	      "Type":"string"
	   }
	]
	return {'Columns':cols}
	

def db_exists():
	response_databases = glue_client.get_databases()
	if(list_contains_name(response_databases['DatabaseList'],ref_database_name)):
		return True
	while 'NextToken' in response_databases:
		response_databases = glue_client.get_databases(NextToken=response_databases['NextToken'])
		if(list_contains_name(response_databases['DatabaseList'],ref_database_name)):
			return True
	return False

def list_contains_name(lst,name):
	for obj in lst:
		if(obj['Name'] == name):
			return True
	return False