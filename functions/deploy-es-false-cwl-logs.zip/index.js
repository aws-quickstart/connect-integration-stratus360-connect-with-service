var https = require("https");
var zlib = require("zlib");
var crypto = require("crypto");

var AWS = require("aws-sdk");

var s3bucket = process.env.S3_BUCKET;
var s3prefix = process.env.S3_PREFIX;
var lastError;
var esStatus = 0;
var s3Status = 0;

exports.handler = function(input, context) {
  // decode input from base64
  var zippedInput = new Buffer(input.awslogs.data, "base64");

  // decompress the input
  zlib.gunzip(zippedInput, function(error, buffer) {
    if (error) {
      context.fail(error);
      return;
    }

    // parse the input from JSON
    var awslogsData = JSON.parse(buffer.toString("utf8"));

    // transform the input to S3 logs
    var s3BulkData = s3transform(awslogsData);

    // put log events to S3
    s3putObject(s3BulkData, function(error, data) {
      if (error) {
        console.log("Error: " + JSON.stringify(error, null, 2));
        endHandler(context, "s3", error);
      } else {
        console.log("Success: " + JSON.stringify(data));
        endHandler(context, "s3");
      }
    });
  });
};

function endHandler(context, caller, error) {
  if (error) {
    lastError = error;
  }

  switch (caller) {
    case "es":
      esStatus = 1;
      break;
    case "s3":
      s3Status = 1;
      break;
    default:
      break;
  }

  if (esStatus === 1 && s3Status === 1) {
    if (lastError) {
      context.fail(JSON.stringify(error));
    } else {
      context.succeed("Success");
    }
  }
}

function s3transform(payload) {
  if (payload.messageType === "CONTROL_MESSAGE") {
    return null;
  }

  var logs = "";

  payload.logEvents.forEach(function(logEvent) {
    var newEntry = {
      id: logEvent.id,
      timestamp: new Date(1 * logEvent.timestamp).toISOString(),
      message: JSON.parse(logEvent.message),
      owner: payload.owner,
      logGroup: payload.logGroup,
      logStream: payload.logStream
    };

    logs = logs + JSON.stringify(newEntry) + "\n";
  });

  return logs;
}

function s3putObject(logEvents, callback) {
  var now = new Date();
  var time_string =
    now.getUTCFullYear() +
    "-" +
    ("0" + (now.getUTCMonth() + 1)).slice(-2) +
    "-" +
    ("0" + now.getUTCDate()).slice(-2) +
    "-" +
    now.getUTCHours() +
    "-" +
    now.getUTCMinutes() +
    "-" +
    now.getUTCSeconds();

  var s3params = {
    Bucket: s3bucket,
    Key:
      s3prefix +
      now.getUTCFullYear() +
      "/" +
      ("0" + (now.getUTCMonth() + 1)).slice(-2) +
      "/" +
      ("0" + now.getUTCDate()).slice(-2) +
      "/" +
      now.getUTCHours() +
      "/" +
      Math.random()
        .toString(36)
        .substr(2, 4) +
      "contactflow_" +
      time_string,
    Body: logEvents
  };

  var s3client = new AWS.S3();
  s3client.putObject(s3params, function(err, data) {
    callback(err, data);
  });
}